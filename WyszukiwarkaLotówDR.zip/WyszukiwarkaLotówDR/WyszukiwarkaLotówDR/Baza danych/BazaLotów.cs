﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WyszukiwarkaLotówDR.Loty;

namespace WyszukiwarkaLotówDR.Baza_danych
{
    public class BazaLotów:IBazaLotów
    {
        List<Lot> listaLotow = new List<Lot>()
        {
            new Lot(0,DateTime.Now.AddDays(1),DateTime.Now.AddDays(4),"Wrocław","Istambuł","WRO","IST",459.99,150),
            new Lot(1,DateTime.Now.AddDays(-1),DateTime.Now.AddDays(1),"Kalisz","Istambuł","WRO","IST",451.99,150),
            new Lot(2,DateTime.Now.AddDays(-1),DateTime.Now.AddDays(1),"Szczecin","Barcelona","WRO","IST",452.99,150),
            new Lot(3,DateTime.Now,DateTime.Now.AddDays(1),"Wrocław","Barcelona","WRO","IST",453.99,150),
            new Lot(4,DateTime.Now,DateTime.Now.AddDays(1),"Kalisz","Barcelona","WRO","IST",453.99,150),
            new Lot(3,DateTime.Now,DateTime.Now.AddDays(1),"Szczecin","Barcelona","WRO","IST",453.99,150)
        };

        public Lot getLot(int id)
        {
            if (id < listaLotow.Count && id >= 0)
            {
                return listaLotow.FirstOrDefault(a => a.idLotu == id);
            }
            else return null;
        }

        public List<Lot> getLoty()
        {
            return listaLotow;
        }
    }
}
